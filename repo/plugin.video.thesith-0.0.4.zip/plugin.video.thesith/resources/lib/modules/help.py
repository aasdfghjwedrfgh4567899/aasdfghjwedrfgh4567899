"""
	Venom Add-on
"""

from resources.lib.modules.control import addonPath, addonId, getthesithVersion, joinPath
from resources.lib.windows.textviewer import TextViewerXML


def get(file):
	thesith_path = addonPath(addonId())
	thesith_version = getthesithVersion()
	helpFile = joinPath(thesith_path, 'resources', 'help', file + '.txt')
	f = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = f.read()
	f.close()
	heading = '[B]thesith -  v%s - %s[/B]' % (thesith_version, file)
	windows = TextViewerXML('textviewer.xml', thesith_path, heading=heading, text=text)
	windows.run()
	del windows
